﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HexMap_Continent : HexMap {
    public override void GenerateMap()
    {
        base.GenerateMap();
    }

    
}
