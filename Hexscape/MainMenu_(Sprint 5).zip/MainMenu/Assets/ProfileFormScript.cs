﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO; 

//When I say "profile", what I'm referring to are 4 profile configuration files
    //Whatever button is pressed will decide which of the 4 are written to and renamed. 
    //Default profile config files names = "profile1.config", "profile2.config", "profile3.config", "profile4.config"

public class ProfileFormScript : MonoBehaviour
{

    //Determines what profile config file written to if new, number depends on which button pressed
    private Component[] Parents;
    private Component ProfileMenu;
    private Component[] ChildRects;
    private Component[] ChildRects2; 
    private Component[] Forms = new Component[2];
    private Component[] fillForm = new Component[2];
    private Component[] viewForm = new Component[2];
    private Component[] Buttons = new Component[4]; 
    private string[] profileLines = {"ProfileName:\t", "ClassName:\t"};
    private string[] profileNames = new string[4]; 

    // Use this for initialization
    void Start()
    {
        Parents = GetComponentsInParent<RectTransform>(true);
        print("Start of loop"); 
        print(Parents.Length);

        for (int x = 0; x < Parents.Length; x++)
        {
            if (Parents[x].name.ToString().Equals("ProfileMenuPanel"))
            {
                ProfileMenu = Parents[x]; 
            }

            if(Parents[x].name.ToString().Equals("ProfileOneButton"))
            {
                Buttons[0] = Parents[x];
            }
            else if(Parents[x].name.ToString().Equals("ProfileTwoButton"))
            {
                Buttons[1] = Parents[x];
            }
            else if(Parents[x].name.ToString().Equals("ProfileThreeButton"))
            {
                Buttons[2] = Parents[x];
            }
            else if(Parents[x].name.ToString().Equals("ProfileFourButton"))
            {
                Buttons[3] = Parents[x];
            }

        }
        ChildRects = ProfileMenu.GetComponentsInChildren<RectTransform>(true);
        print(ChildRects.Length); 
        for (int x = 0; x < ChildRects.Length; x++)
        {
            if (ChildRects[x].name.ToString().Equals("ProfileViewPanel"))
            {
                Forms[0] = ChildRects[x];
            }
            else if(ChildRects[x].name.ToString().Equals("ProfileFormPanel"))
            {
                Forms[1] = ChildRects[x]; 
            }
        }

        ChildRects = Forms[0].GetComponentsInChildren<UnityEngine.UI.Text>(true);
       print( ChildRects.Length); 
        for (int x = 0; x < ChildRects.Length; x++)
        {
            if (ChildRects[x].name.ToString().Equals("ProfileFormTitle"))
            {
                fillForm[0] = ChildRects[x];
                print(ChildRects[x]);
            }
            else if (ChildRects[x].name.ToString().Equals("ProfileClassText"))
            {
                fillForm[1] = ChildRects[x];
                print(ChildRects[x]);
            }

        }

        ChildRects = Forms[1].GetComponentsInChildren<RectTransform>(true);
        for (int x = 0; x < ChildRects.Length; x++)
        {
            
            if (ChildRects[x].name.ToString().Equals("ChooseClassDropdown"))
            {
                viewForm[0] = ChildRects[x];
                print(ChildRects[x]);
            }
            else if (ChildRects[x].name.ToString().Equals("ProfileNameInputField"))
            {
                viewForm[0] = ChildRects[x];
                print(ChildRects[x]);
            }
        }

    }

    public void isNewProfile()
    {
        UnityEngine.UI.Text buttonText = gameObject.GetComponentInChildren<UnityEngine.UI.Text>(true);

        if(buttonText.text == "NewProfile")
        {
            print("This profile is empty");
            Forms[1].gameObject.SetActive(true); 
            
        }
        else
        {
            print("This profile is not empty");
            if (fileExist(buttonText.text))
            {

                Forms[0].gameObject.SetActive(true);

            }
            else
            {
                buttonText.text = "NewProfile"; 
            }

        }

    }

    public bool fileExist(string fileName)
    {
        bool Exist = false;

        fileName = fileName + ".config";
        Exist = File.Exists(fileName);

        if (Exist == true)
        {
            print("File exists..."); 
            return Exist; 
        }
        else
        {
            print("File does not exist...");
        }

        return Exist; 
    }

    public bool createFile(string fileName)
    {
        System.IO.FileStream fileStream;

       if(fileExist(fileName))
        {
            print("File not created...");
            return false; 
        }
       else
        {
            fileStream = File.Open(fileName + ".config", FileMode.Create);
            fileStream.Close();
            
           
           
            return true; 
        }

    }

    public void readFillForm()
    {
        string profileName;
        string className;
        string[] Data = new string[2]; 
        UnityEngine.UI.Dropdown userClass;
        UnityEngine.UI.InputField userName;

        userClass = Forms[1].GetComponentInChildren<UnityEngine.UI.Dropdown>(true);
        userName = Forms[1].GetComponentInChildren<UnityEngine.UI.InputField>(true);

       className = userClass.options[userClass.value].text;
       profileName = userName.text;

        print(className);
        print(profileName); 

        if(profileName == "NewProfile")
        {
            print("Invalid name, please type another name..."); 
        }
        else if(profileName != "" && profileName != "Enter Text...")
        {
            Data[0] = profileLines[0] + profileName;
            Data[1] = profileLines[1] + className;
            writeFile(profileName, Data); 
        }
    }

    public void writeFile(string fileName, string[] Data)
    {

        if(fileExist(fileName))
        {
            print("Profile already exists, please type another name...");
            return; 
        }
        else if (createFile(fileName))
        {
            print("File has been created!");

            for(int x = 0; x < Data.Length; x++)
            {
                
            }
            File.WriteAllLines(fileName + ".config", Data); 
        }
    }

    public void readFileForButtons()
    {

    }

    public void readFileForViewForm()
    {

    }

    public void changeProfileButtonText(int NumberButton)
    {
        UnityEngine.UI.Text buttonText = Buttons[NumberButton].GetComponentInChildren<UnityEngine.UI.Text>(true);
    }

    public void updateAllProfileButtonText()
    {
        for(int x = 0; x < 3; x++)
        {

        }
    }

}