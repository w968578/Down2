﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//When I say "profile", what I'm referring to are 4 profile configuration files
    //Whatever button is pressed will decide which of the 4 are written to and renamed. 
    //Default profile config files names = "profile1.config", "profile2.config", "profile3.config", "profile4.config"

public class ProfileFormScript : MonoBehaviour
{

    //Checks which profile buttons are new and blank and which ones are already written
    private bool[] newProfile = new bool[3];
    //Determines what profile config file written to if new, number depends on which button pressed
    private int profileButton; 

    // Use this for initialization
    void Start()
    {
        gameObject.SetActive(false);
    }

    //Sets profile form to active when button clicked
    public void activateForm()
    {
        print("Form activated...");
        gameObject.SetActive(true); 
        
    }

    //Sets profile form to inactive when done
    public void deactivateForm()
    {
        print("Form deactivated...");
        gameObject.SetActive(false); 
    }

    //Reads existing profile data
        //Also determines if profile exists or not initially...
    public void readProfileData(int Profile)
    {
        print("Reading file..."); 
    }

    //Writes data to a profile
        //Takes into account if profile exists or not when writing
    public void writeProfileData(int Profile)
    {
        print("Writing file...");
    }

}


