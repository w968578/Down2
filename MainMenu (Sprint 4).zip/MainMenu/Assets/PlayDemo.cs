﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement; 
using UnityEngine;

public class PlayDemo : MonoBehaviour {

    public void Play()
    {
        SceneManager.LoadScene("practice", LoadSceneMode.Single); 
       
    }

     
}
